  import React, { useEffect } from 'react';
  import { Document, Page,Text, Image, StyleSheet, View } from '@react-pdf/renderer';
  import './style.css'

  // Create styles for the PDF
  const styles = StyleSheet.create({
      horizontalLine: {
      height:' 1',
      backgroundColor: 'black',
      marginVertical: '10', // Adjust spacing around the line
    },
    page: {
      // padding: 30,
      fontSize: '12',
      // border: '1px solid blue',
      // width:'40%',
      margin:'auto',
    },
    title: {
      fontSize: 18,
      marginBottom: 10,
    },
    content: {
      marginBottom: 5,
    },
    headers: {
      flexDirection: 'column',
      marginBottom: '4%',
    },
    one: {
      flexDirection: 'row',          // Align children horizontally
      borderWidth: '1',                // Border width
      borderColor: 'black',          // Border color
      borderStyle: 'solid',          // Border style
      justifyContent: 'space-around', // Space items evenly with equal space around
      width: '100%',                 // Full width of the container
    },
    imageContainer: {
      border: '1px solid red',
      width: 100,
      height: 100,
    },
    li :{
      listStyle: 'none',
      padding: '5px 10px',
  },
  td :{
    border:' 1px solid black',
    /* width: 100%, */
  },

  tr :{
    width: '100%',
  },

  table :{
    borderCollapse: 'collapse',
  },

  input: {
    outline: 'none',
    border: 'none',
    width: '100%',
    /* border: 1px solid red, */
    padding:' 9px 0px',
  },

  greet: {
    fontFamily: 'Playwrite IN, serif !important',
  },

  footer :{

    display: 'flex',
    flexDirection: 'row',
    justifyContent:' space-between',
    marginTop: '30px',
    background: '#8b3a131c',
    padding:' 20px',
    columnGap:'30%',

  },
  view: {
    display: 'flex',
    flexDirection:"row",
    columnGap: '5px',
  },

  doc_page:{
    display: 'flex',
    flexDirection:'column',
    flexWrap:'wrap',
    flexDirection: 'column',
    padding:'2%',
  },
  main_view_container:{
    display: 'flex',
    flexDirection: 'column',
    rowGap: '1%',
  },
  first_div:{
    display: 'flex',
    justifyContent: 'space-between',
  },
  img_cont:{
    width: '150px',
      height: '150px',
      border: '1px solid red',
  },
  invoice_header:{
    display: 'flex',
    flexDirection: 'column',
    // padding: 'right',

  },
  second:{
  display: 'flex',
  flexDirection:'row',
  justifyContent: 'space-between',
  },
  invoice_cont : {
  display:'flex',
  flexDirection:'column',
  },
  prd_table_container:{
    display: 'flex',
    justifyontent: 'space-between',
    // borderBottom: '1px solid black',
    padding: '10px 0px',
    letterSpacing:'1px',
    fonWeight:'400',
    width:'100%',
  },
  Image:{
    width: '150px',
    height: '150px',
  },
Items:{
display:'flex',
flexDirection:'row',
justifyContent:'space-between',
alignItems:'center',
},
Text:{
  lineHeight:"20px",
}
  });

  const PdfGenerater = ({data}) => {
    useEffect(()=>{
      console.log(data);
      
    },[data])
    return(
      
      <Document>
      <Page style={{ ...styles.page,...styles.doc_page,marginLeft:'15%',marginTop:'10%'}}>
      {/* <a href={blobUrl} download="generated.pdf">
            <button>Download PDF</button>
          </a> */}
        <View style={{...styles.main_view_container,marginLeft:'15%',marginTop:'10%',marginBottom:'10px'}}>
          {/* first div */}
          <View  style={{ display:'flex',flexDirection:'row',justifyContent:'space-between',columnGap:'25%',marginBottom:'20px'}}>
            <View className="img-cont" style={{...styles.img_cont}}>
              <Image style={{width:'150px',height:'150px'}} src={"data:image/png,base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAAAeFBMVEX///8AAACbm5tra2v29vaioqL7+/utra18fHxycnK0tLRaWlrv7+9vb2/t7e2NjY0SEhJhYWHW1tbKysqEhIQqKio0NDTCwsJERETf398+Pj5KSkohISGpqand3d3k5OS9vb1SUlIZGRmIiIjS0tKUlJQdHR01NTVMir6jAAAFSElEQVR4nO2d6XLiMBCEsQmYY8HchADBhJB9/zfc5UgWY8m3ptVeff9dNdNlS6M55FbL4XA4ijH3F8MPtBEMHDpH7wraEPuJ7kr95QVti+V0Jp7nxMrF3ovRRdtjMfNJXCu3ZumZes+gLbKWWUIq7xVtk634Sa28HtooS+krtPJ8tFV2klyuLryjzbKStlIrt76rOKm1mqLtspFArZU3QBtmIe8ardxXqGCn0coFDkmUQcOFDdoy+5jrtHLLe5Lns7N7sfSoTjlX+mjLLESnlcv7JenotHIxVhKdVkO0YRay1onl8slJthqtXLohyYtGqwBtmI1Eaq1CtF1Woj7puAhLidMqPweVVi7XoOZToZWrUWgYJLWao22ylsQh+u0X2iR7CZ+06qANsplFTKqRe63SeBRr5HJ96Zy/ldr6LnuVxWDysduO/EitVPf/yjwc5oF/6vUW/uC9iOObQbi9l8eW28X+s/Fv3cs6XMa3utM6j9Oz4FURqbYHB+MWwwjUearXTvqG99lTPnZ7x/xGbpYHTUvMlVWge78OKUrdtW5ceD9TfUYxhlHyqfFZV8OPMWlUGWM8zOOz14+9Iy9+psA/LD9RrtXO8/klhVF0W4Nm/ir/QxemzdgcZ8tsVx9Z9c7appA0mrB0aQvxtcOfo1e30JqBvMGmW3DlqQj1NIGuAGiMN7TH5RHXyvOOaJ/L0v2SF4u2YvYG0Io1CZ12FjQJYzC/z3bLCCFhclBZVjbPkrIrqeAZpyY4i/xyh5xHOFM1vyBazdBul0PyRPgDaUJeMQRuHtZkPCIcJX2v9JOCBiFdr1qtfBn3WqFtZB7La9VG+1waQIyFdrk88lqt0S6XRj5uIB5/WmR7VzOUh+cb4loRv1jyuRnaEAuR9EN7XIHMFqG62aM9roD2jgFTsB4KW4Dw/QvtcQVUU0pG4cwk31BMKZklQntcgQKNa/VAvGTJl1bRDlchfx+oE0s8cviNdrgKwloxHwzlxeLNkQL610ZojysgXop2YhWA+TMUF4t5gRcXi7g/GdA+g/a4Al0nVgHExWJtnrkgLhbzMFiu0dM6OaM9roDubkNjbNEeV0B+VICw7/0b8UwpcVeI9l8K5iAeydTe424O3lFyQD8p5xzYBfkQnjmI/y0vFm+3g3wvG/Gqpb333iALtNNlEW92uEDbKIkQa4d2uiyy917cYU3Fyx94LpAGW4AY/kKE9rsUiLD0AmcWEHP5Bala8omHO4zz5BuUWJTXjX3A1CLMbWGChysTuptocN/hXxZsOXmkWHTz0udsj4xCtS0CRsrjUPXWiDd4P0FVHoPFpXfQ/hcDqxXZLYniI5oxyBKn0CV+hfa+KEegWHSJQFAK8Ara9+KgslqUs62aH6sKwNhlirl8k3RABfVqkcUNdyAFRNYKImZDZB0wB9z9x7gV3kBcRs24Fd6QPyEy/0JZXCy0w1WQDh8oi9I/yE6nMI+1tqSn8XlX9xuSCWaqoo4SuWCL9gdFD4iJxVaKViHVvsy9E34j0ydCe855QiJ+WKKdrAuJ+IE9aviH+Yu8qer1GZi+Q/iEdrBWzOYfyI85CUz21SybEGHFMHg7xhjtW+2Y2xI3aNcMYEot4rvzUzBzt1YztWq1unnWrW3vFETz9SDs5cpXsFa+cnBM97y/jvs+XvfTH9jRjpLnIaXp+6ReqDcp4/xk7ZCFman7RdppCZa1+t+SO7rRk+Ik7zJYBVnH4PE+2ThBNkhRls5jo9u0ky+mHO9HDzeCj5p0cs5gE5ymx2E7DIp9SYdo74dhJ2hquOBwOBwODH8ANaBTm6RouNYAAAAASUVORK5CYII="} ></Image>
            </View>

            <View style={{...styles.invoice_header,display:'flex',flexDirection:'column',rowGap:'2%'}} >
              <Text style={{letterSpacing:'10px',fontWeight:'500'}}>INVOICE</Text> 
              <Text style={{fontWeight:'500',letterSpacing:'2px'}}>Business Name</Text> 
              <Text>Business Address</Text> 
              <Text>Phone</Text> 
              <Text>Email</Text> 
            </View>

          </View>

          {/* Second div */}
          <View class="second" style={{display:'flex',flexDirection:'row',...styles.second}} >

            <View style={{display:'flex',flexDirection:'column',}}>
              <View style={{...styles.view}}>
                <Text style={{fontWeight:'400',...styles.Text}}>ISSUE TO:</Text> 
                <Text style={{...styles.Text}}>{data[1]?.name||'null'}</Text> 
                {/* <Text>name</Text>  */}
                {/* <Text style={styles.p}>Client Details: {data[0]?.clientDetail || 'N/A'}</Text>  */}

              </View>
              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>Client Name:</Text> 
                <Text style={{...styles.Text}}>{data[0]?.cname||'null'}</Text> 
              </View>
              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>Addres Line :</Text> 
                <Text style={{...styles.Text}}>{data[0]?.address1||'null'}</Text> 
              </View>

              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>Addres Line :</Text> 
                <Text style={{...styles.Text}}>{data[0]?.address2||'null'}</Text> 
              </View>
              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>Email Address:</Text> 
                <Text style={{...styles.Text}}>{data[0]?.mail||'null'}</Text> 
              </View>
            </View>

            <View className="invoice-cont" style={{...styles.invoice_cont}} >
              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>INVOICE NO:</Text> 
                <Text style={{...styles.Text}}>{data[2]?.invoiceNo||'null'}</Text> 
              </View>
              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>Issue Date:</Text> 
                <Text style={{...styles.Text}}>{data[2]?.issueDate||'null'}</Text> 
              </View>
              <View style={{...styles.view}}>
                <Text style={{...styles.Text}}>Due Date:</Text> 
                <Text style={{...styles.Text}}>{data[2]?.dueDate||'null'}</Text> 
              </View>
            </View>
          </View>
  <View style={{...styles.prd_table_container}}>
  <View className="prd-table-container" style={{...styles.view,...styles.Items,borderBottom:'1px solid black',paddingBottom:'10px'}}>
    <Text>DESCRIPTION</Text> 
    <Text>AMOUNT</Text> 
  </View>
  <View style={{...styles.Items}}>
    <Text style={{...styles.li,...styles.Text}}>item1</Text>
    <Text  style={{...styles.li,...styles.Text}}>100</Text >
  </View>,
  <View style={{...styles.Items}}>
    <Text  style={{...styles.li,...styles.Text}}>item1</Text >
    <Text  style={{...styles.li,...styles.Text}}>100</Text >
  </View>
  <View style={{...styles.Items}}>
    <Text  style={{...styles.li,...styles.Text}} >item1</Text >
    <Text  style={{...styles.li,...styles.Text}}>100</Text >
  </View>
  <View style={{...styles.Items}}>
    <Text  style={{...styles.li,...styles.Text}}>item1</Text >
    <Text  style={{...styles.li,...styles.Text}}>100</Text >
  </View>
  <View style={{...styles.Items}}>
    <Text  style={{...styles.li,...styles.Text}}>item1</Text >
    <Text  style={{...styles.li,...styles.Text}}>100</Text >
  </View>
  </View>
  <View style={{ display: 'flex',
  flexDirection:'row',
  justifyContent:'space-between',
      borderTop:' 1px solid black',
      borderBottom:' 1px solid black',
      padding:' 10px 10px',
      justifyContent:' space-between',...styles.Items
      }}>
    <Text style={{...styles.Text}}>Total</Text> 
    <Text style={{...styles.Text}}>500</Text> 
  </View>
  <View>
      <div className="total-amount" style={{...styles.Items}}>
          <Text  style={{...styles.li,...styles.Text}}>TOTAL</Text >
          <Text  style={{...styles.li,...styles.Text}}>90</Text >
      </div>
      <div className="total-amount" style={{...styles.Items}}>
      <Text  style={{...styles.li,...styles.Text}}>TAX</Text >
      <Text  style={{...styles.li,...styles.Text}}>90</Text >
      </div>
      <div className="total-amount" style={{...styles.Items}}>
      <Text  style={{...styles.li,...styles.Text}}>AMOUNT DUE</Text >
      <Text  style={{...styles.li,...styles.Text}}>90</Text >
      </div>
  </View>
  <View className="footer" style={{...styles.footer}}>
    <View >
      <Text style={{fontWeight:'500'}}>BANK DETAILS</Text> 
      <Text style={{...styles.Text}}>Bank Name</Text> 
      <Text style={{...styles.Text}}>Account Name</Text> 
      <Text style={{...styles.Text}}>Account No</Text> 
    </View>
    <View>
      <Text className='greet' style={{ 
    fontOpticalSizing: 'auto',
    fontWeight:100 ,
    fontStyle: 'normal',fontSize:'30px', transform: 'rotate(-10deg)',width:'60%',...styles.Text
    }}>Thank You..!</Text> 
    </View>
  </View>
        </View>

        {/* <Text style={styles.title}>Hello, !</Text> 
        <Text style={styles.content}>This is a dynamically generated PDF.</Text>  */}
      </Page>
    </Document>
    )
  }
  


  export default PdfGenerater;